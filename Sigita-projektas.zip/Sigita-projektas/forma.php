<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "forma";

$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
if(!empty($name) && !empty($email) && !empty($message)){
  if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $from = "$email";
    $to = "whimsical.7@gmail.com";
    $subject = "New message";
    $autorius = 'From: ' . $name . ', ' . $email;
    $zinute = htmlspecialchars($message);
    mail($to, $subject, $autorius, $zinute, $from);
    echo "<script>alert('Thank you. We will keep in touch soon.');</script>";
  }
}
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO klientau (name, email, message)
VALUES ('$_POST[name]', '$_POST[email]', '$_POST[message]')";
if ($conn->query($sql) === TRUE) {
  echo "Thank you";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
  $sql = "SELECT * FROM klientau";
  $result = $mysqli->query($sql);
  while($array = $result->fetch_assoc()){
    var_dump($array);
  }
  mysqli_query($mysqli, "INSERT INTO klientau (name, email, message)
  VALUES('$_POST[name]', '$_POST[email]', '$_POST[message]')");
}
$conn->close();
?>
